import FeedbackCard from "../components/FeedbackCard";

const Feedback = () => {
  return (
    <div>
      <FeedbackCard />
    </div>
  )
}

export default Feedback;