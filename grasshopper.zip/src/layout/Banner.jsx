const Banner = () => {
  return(
    <div className="bg-green-500 h-[50px] w-full flex items-center justify-center text-lg text-white font-medium">
      Grasshopper is shutting down on June 15, 2023
    </div>
  )
}

export default Banner;